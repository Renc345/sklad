-- MySQL dump 10.13  Distrib 8.0.30, for Win64 (x86_64)
--
-- Host: localhost    Database: sklad
-- ------------------------------------------------------
-- Server version	8.0.31

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `manufacturer`
--

DROP TABLE IF EXISTS `manufacturer`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `manufacturer` (
  `idmanufacturer` int NOT NULL AUTO_INCREMENT,
  `FIO` varchar(45) NOT NULL,
  `phone` varchar(45) NOT NULL,
  `address` varchar(150) NOT NULL,
  PRIMARY KEY (`idmanufacturer`),
  KEY `nameIdmanufacturer` (`idmanufacturer`),
  KEY `fio` (`FIO`),
  KEY `adres_phone` (`address`,`phone`),
  KEY `phone_adres` (`phone`,`address`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `manufacturer`
--

LOCK TABLES `manufacturer` WRITE;
/*!40000 ALTER TABLE `manufacturer` DISABLE KEYS */;
INSERT INTO `manufacturer` VALUES (1,'Анохин Даниил Антонович','+7(3519)92-74-47','г. Красноярск, ул. Ленина, 5, оф. 100'),(2,'Иванова Ксения Львовна','+7(3519)21-29-72 ',' г. Краснодар, ул. Красноармейская, 46, оф. 84'),(3,'Смирнов Евгений Максимович','+7(499)281-95-48 ','Москва'),(4,'Лебедев Тимофей Павлович','+7(347)147-03-83 ',' г. Краснодар, ул. Первомайская, 9, оф. 81'),(5,'Островский Руслан Тимурович','+7(846)652-95-46 ',' г. Москва, ул. Майская, 10, оф. 60'),(6,'Поликарпов Михаил Константинович','+7(863)894-60-48 ',' г. Челябинск, ул. Калинина, 18, оф. 78'),(7,'Борисов Никита Михайлович','+7(4862)59-74-77 ',' г. Тольятти, ул. Садовая, 35, оф. 86'),(8,'Овсянникова Диана Макаровна','+7(3952)89-84-08 ',' г. Москва, ул. Пионерская, 2, оф. 21'),(9,'Козлов Марк Денисович','+7(495)687-99-33 ',' г. Санкт-Петербург, ул. Труда, 12, оф. 49'),(10,'Жилин Юрий Эмирович','+7(4212)25-76-91 ',' г. Самара, ул. Рабочая, 25, оф. 7');
/*!40000 ALTER TABLE `manufacturer` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-12-19 15:15:07
